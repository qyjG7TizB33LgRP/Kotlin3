package com.example.kotlin3

data class Character(
    var name: String? =null,
    var image: String? =null,
    var movie: Boolean? =false


)
